
<?php
session_start();
include('include/config.php');
if(strlen($_SESSION['alogin'])==0)
	{	
header('location:index.php');
}
else{
date_default_timezone_set('Asia/Kolkata');// change according timezone
$currentTime = date( 'd-m-Y h:i:s A', time () );


?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Admin|Dashboard</title>
       
	<link type="text/css" href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<link type="text/css" href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">
	<link type="text/css" href="css/theme.css" rel="stylesheet">
	<link type="text/css" href="images/icons/css/font-awesome.css" rel="stylesheet">
	<link type="text/css" href='http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600' rel='stylesheet'>
</head>
<body>
<?php include('include/header.php');?>

	<div class="wrapper">
		<div class="container">
			<div class="row">
<?php include('include/sidebar.php');?>				
			<div class="span9">
					<div class="content">

						<div class="module">
							<div class="module-head">
								<h3>Dashboard</h3>
							</div>
							<div class="module-body">

							
							<table cellpadding="30" border="3" width ="840">
									<thead>
								<tr>
											<th> <center>Number of Owner </center></th>
											<th> <center>Number of Donor </center> </th>
											<th> <center>Number of Commumity Pantry </center></th>
										
										</tr>
									</thead> 
								
<tbody>
<?php 

{
?>										
	<tr> 	
		<td>  <center> <div class="row">
            <div class="col-lg-9 main-chart">
                              
            	<div class="col-xl-2 col-xl-2 box0">
                     <div>
                 
                  </div></div>

                  	<div class="col-xl-2 col-xl-2 box0">
                    	<div class="box1">
                       	<span class="li_mail"></span>  
                            <?php 
                   
 $rt = mysqli_query($con,"SELECT * FROM users WHERE user_type = 'Owner'");
$num1 = mysqli_num_rows($rt);
{?>
					  			<h3><?php echo htmlentities($num1);?></h3>
                  			</div> 
					  			
                  		</div>
                      <?php }?> <center></td>

                      
											<td>  <center>
                      <div class="col-xl-2 col-xl-2 box0">

                        <div class="box1">
                  <span class="li_mail"></span> 
                    <?php 
                
$rt = mysqli_query($con,"SELECT * FROM users WHERE user_type = 'Donor'");
$num1 = mysqli_num_rows($rt);
{?>
                  <h3><?php echo htmlentities($num1);?></h3>
                        </div>
                 
                      </div>
  <?php }?>   <center></td>
											<td>  <center>
                      <div class="col-xl-2 col-xl-2 box0">
                        <div class="box1">
                  <span class="li_mail"></span>
                       <?php 
                
$rt = mysqli_query($con,"SELECT * FROM community_pantry");
$num1 = mysqli_num_rows($rt);
{?>
                  <h3><?php echo htmlentities($num1);?></h3>
                        </div>
                
                      </div>

<?php }?>  <center></td>
										
										
											</td>
                     	</tr> 

										<?php  } ?>
										</tbody>
								</table>
							</div>
						</div>						




             <!-- /table -->

                  	</div><!-- /row mt -->	
                								
	</div><!--/.wrapper-->

	

	<script src="scripts/jquery-1.9.1.min.js" type="text/javascript"></script>
	<script src="scripts/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script>
	<script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
	<script src="scripts/flot/jquery.flot.js" type="text/javascript"></script>
	<script src="scripts/datatables/jquery.dataTables.js"></script>
	<script>
		$(document).ready(function() {
			$('.datatable-1').dataTable();
			$('.dataTables_paginate').addClass("btn-group datatable-pagination");
			$('.dataTables_paginate > a').wrapInner('<span />');
			$('.dataTables_paginate > a:first-child').append('<i class="icon-chevron-left shaded"></i>');
			$('.dataTables_paginate > a:last-child').append('<i class="icon-chevron-right shaded"></i>');
		} );
	</script>

</body>

<?php } ?>